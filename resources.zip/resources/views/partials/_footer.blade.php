<!-- footer -->
<div class="footer">
    <p>© 2020 ponnobazar.online. All rights reserved | Developed by <a href="">Md. Ashiqur Rahaman</a></p>
</div>
<!-- //footer -->
