<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>All Rights Reserved. © 2021 ponnobazar.digital</p>
        </div>
        <div class="float-end">
            <p>Developed by <a href="https://picredo.com/">piCredo Software Ltd</a></p>
        </div>
    </div>
</footer>
