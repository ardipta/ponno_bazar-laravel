<!--- header ---->
<div class="header">
    <div class="container">
        <div class="logo wow fadeInDown animated" data-wow-delay=".5s">
            <a href="{{route('index')}}"><img src="{{asset('images/logo1.webp')}}" style="max-width: 100%; height: 50px"></a>
        </div>
        <div class="bus wow fadeInUp animated" data-wow-delay=".5s">
            <a href="#busTicket" class="buses active">BUSES</a>
            <a href="#">HOTELS</a>
        </div>
        <div class="lock fadeInDown animated" data-wow-delay=".5s">
            <li><i class="fa fa-lock"></i></li>
            <li><div class="securetxt">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!--- /header ---->
