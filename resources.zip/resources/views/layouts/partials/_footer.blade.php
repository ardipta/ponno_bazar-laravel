<!--- footer-top ---->
{{--<div class="footer-top">--}}
{{--    <div class="container">--}}
{{--        <div class="col-md-6 footer-left wow fadeInLeft animated" data-wow-delay=".5s">--}}
{{--            <h3>Bus Operators</h3>--}}
{{--            <ul>--}}
{{--                <li><a href="bus.html">New York  Charter </a></li>--}}
{{--                <li><a href="bus.html">Washington Charter</a></li>--}}
{{--                <li><a href="bus.html">Los Angeles Charter</a></li>--}}
{{--                <li><a href="bus.html">Chicago Charter</a></li>--}}
{{--                <li><a href="bus.html">Orlando Charter</a></li>--}}
{{--                <li><a href="bus.html">New Orleans Charter</a></li>--}}
{{--                <li><a href="bus.html">Houston Charter</a></li>--}}
{{--                <li><a href="bus.html">Nashville Charter</a></li>--}}
{{--                <li><a href="bus.html">Charlotte Charter</a></li>--}}
{{--                <li><a href="bus.html">Toronto Charter</a></li>--}}
{{--                <li><a href="bus.html">Washington Charter</a></li>--}}
{{--                <li><a href="bus.html">Los Angeles Charter</a></li>--}}
{{--                <li><a href="bus.html">Chicago Charter</a></li>--}}
{{--                <li><a href="bus.html">Orlando Charter</a></li>--}}
{{--                <li><a href="bus.html">New Orleans Charter</a></li>--}}
{{--                <div class="clearfix"></div>--}}
{{--            </ul>--}}
{{--        </div>--}}
{{--        <div class="col-md-6 footer-left wow fadeInRight animated" data-wow-delay=".5s">--}}
{{--            <h3>Bus Routes</h3>--}}
{{--            <ul>--}}
{{--                <li><a href="travels.html">Alabama-California</a></li>--}}
{{--                <li><a href="travels.html">Alaska-Colorado</a></li>--}}
{{--                <li><a href="travels.html">Arizona-Delaware</a></li>--}}
{{--                <li><a href="travels.html">Arkansas-Florida</a></li>--}}
{{--                <li><a href="travels.html">Kansas-Georgia</a></li>--}}
{{--                <li><a href="travels.html">Iowa-Hawaii</a></li>--}}
{{--                <li><a href="travels.html">Indiana-Illinois</a></li>--}}
{{--                <li><a href="travels.html">Illinois-Florida</a></li>--}}
{{--                <li><a href="travels.html">Idaho-Indiana</a></li>--}}
{{--                <li><a href="travels.html">Hawaii-Iowa</a></li>--}}
{{--                <li><a href="travels.html">Georgia-Kansas</a></li>--}}
{{--                <li><a href="travels.html">Florida-Arkansas</a></li>--}}
{{--                <li><a href="travels.html">Delaware-Arizona</a></li>--}}
{{--                <li><a href="travels.html">Colorado-Alaska</a></li>--}}
{{--                <li><a href="travels.html">California-Alabama</a></li>--}}
{{--                <div class="clearfix"></div>--}}
{{--            </ul>--}}
{{--        </div>--}}
{{--        <div class="clearfix"></div>--}}
{{--    </div>--}}
{{--</div>--}}
<!--- /footer-top ---->
<!---copy-right ---->
<div class="copy-right" style="left: 0;bottom: 0;width: 100%;position: fixed;">
    <div class="container">
        <div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
            <ul>
                <li><a class="facebook" href="#"><span>Facebook</span></a></li>
                <li><a class="twitter" href="#"><span>Twitter</span></a></li>
                <li><a class="flickr" href="#"><span>Flickr</span></a></li>
                <li><a class="googleplus" href="#"><span>Google+</span></a></li>
                <li><a class="dribbble" href="#"><span>Dribbble</span></a></li>
            </ul>
        </div>
        <p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">© 2021 Ponnobazar.digital . All Rights Reserved | Developed by  <a href="https://picredo.com/" target="_blank">piCredo Software Ltd.</a> </p>
    </div>
</div>
<!--- /copy-right ---->
