<!-- top-header -->
<div class="top-header">
    <div class="container">
        <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
            <li class="hm"><a href="#"><i class="fa fa-envelope"></i></a></li>
            <li class="prnt"><a href="">info@ponnobazar.digital</a></li>
        </ul>
        <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s">
            <li class="tol">Call Center : +880 156-808-6107</li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div>
<!--- /top-header ---->
