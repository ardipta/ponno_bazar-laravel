<div class="text-center" style="left: 0;bottom: 0;width: 100%;position: fixed;">
    <p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">© 2021 Ponnobazar.digital . All Rights Reserved | Developed by  <a href="https://picredo.com/" style="text-decoration: none" target="_blank">piCredo Software Ltd.</a> </p>
</div>
